import React from 'react'

const Parrafo = () => {
    return (
        <div>
            <p>Bienvenidos a mi sitio web</p>
        </div>
    )
}

export default Parrafo
