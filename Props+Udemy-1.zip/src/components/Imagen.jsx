import React from 'react'

const Imagen = ({urlImagen}) => {
    return (
        <img src={urlImagen} className='mr-3' alt=""/>
    )
}

export default Imagen
